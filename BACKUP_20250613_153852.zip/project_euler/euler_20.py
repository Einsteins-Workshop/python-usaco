# https://projecteuler.net/problem=20
#
# n! means n x (n-1) x ... x 3 x 2 x 1
# For example, 10! = 10 x 9 x ... x 3 x 2 x 1 3628800,
# and the sum of the digits in the number 10! is 3+6+2+8+8+0+0=27
#
# Find the sum of the digits in the number 100!


# Replace the below with your program.
factor=1
factorials=[]
for x in range(1, 100+1):
    factor=factor*x
factor=str(factor)
for i in range(len(factor)):
    factorials.append(int(factor[i]))
print(sum(factorials))