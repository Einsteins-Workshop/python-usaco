#https://www.hackerrank.com/challenges/py-hello-world/

#Print Hello, World! to stdout.
print("Hello world")
