# Ask for a number

# Loop from 1 to that number
    # For each number in that loop, print:
    # FizzBuzz if the number is divisible by 3 and 5
    # Fizz if the number is divisible by 3 but not 5
    # Buzz if the number is divisible by 5 but not 3
    # The number otherwise