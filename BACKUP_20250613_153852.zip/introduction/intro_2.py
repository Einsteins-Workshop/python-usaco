# Print the output of 7 divided by 3.  Try using both / and // and see the difference.

# Convert a number to a string

# What is wrong with the following statement?  Try to fix it.
print("2 + 4 = " + 2 + 4)

# Using the input() function, ask the user for two variables and
# print out the sum, difference, product, and division of the two numbers.

# Write a program that asks for the two legs of a right triangle, and returns the
# hypotenuse by the pythagorean theorem: c = sqrt(pow(a,2) + pow(b, 2))

# Create a list of numbers from 1 to 30. For each element of the list, print Fizz if the
# number is divisible by three, Buzz if it is divisible by five, FizzBuzz if divisible by fifteen, and just the number otherwise.

# Using a dictionary, create an "orc" that is a dictionary, with
# the name mapping to "Orc" and a default hp attribute of 10.
# As the user to input the damage.  Record that to the "damage" attribute of the orc.
# Then print out the orc.

# Ask the user for an input.  Print
#      "the number is 10" if the number is 10,
#      "the number is less than 10" if the number is less than 10
#      "the number is greater than 10" if the number is greater than 10
#      " You didn't give me a number! if the input is not a number.