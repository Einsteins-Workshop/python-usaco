# Make your own mad lib

# Ask the user for a variety of inputs
color = input("Enter a color: ")
plural_noun = input("Enter a plural noun: ")
noun = input("Enter a noun: ")
adjective = input("Enter an adjective")

# Then print your mad lib using the user input
print("Roses are ", color)
print(plural_noun + " are blue")
print(f"{noun} is {adjective}")
print("and so are you.")
