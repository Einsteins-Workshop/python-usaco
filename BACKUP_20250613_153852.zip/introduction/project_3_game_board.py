# We are going to print a tic-tac-toe board
# First, store the board state in a list

# Extend the board to contain nine squares
board = [1, 2, 3, 4]

# Print the board three elements at a time.
print(board[0], "|", board[1], "|", board[2])
print("---------")
# Continue printing the rest of the board

# Ask the user for a square

# Replace the appropriate part of the board list with an "X"

# Print the board again with the new X.