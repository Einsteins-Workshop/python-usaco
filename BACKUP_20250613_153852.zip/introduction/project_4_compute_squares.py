# Ask the user for a number
number = int(input("Enter a number\n"))

# Use a for loop and the range function to loop from 1 to number
for i in range(0): # This needs to be completed.
    pass # Remove this
    # Print the square of the loop variable i.
