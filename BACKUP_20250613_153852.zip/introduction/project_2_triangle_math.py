# Ask the user for one leg of a right triangle
first_leg = int(input("Enter the length of a leg of a right triangle\n"))

# Ask the user for the length of the second leg of the triangle

# Compute and print the area of the triangle (first_leg times second_leg divided by 2)

# Compute and print the hypotenuse of the triangle (the square root of the first_leg squared + the second leg squared).
